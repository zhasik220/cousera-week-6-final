Final devops bdd and tdd project
